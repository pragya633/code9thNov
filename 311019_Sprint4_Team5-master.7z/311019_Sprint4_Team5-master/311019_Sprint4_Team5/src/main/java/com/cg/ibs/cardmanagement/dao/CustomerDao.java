
package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CustomerDao {

	boolean verifyUCI(BigInteger uci) throws IBSException;

	String getNewName(BigInteger account) throws IBSException;

}
