package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

@Repository
public class CreditCardTransactionDaoImpl implements CreditCardTransactionDao {
	
	private static Logger logger = Logger.getLogger(CreditCardTransactionDaoImpl.class);
	private EntityManager entityManager;

	public CreditCardTransactionDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
	}

	@Override
	public boolean verifyCreditTransactionId(BigInteger transactionId) throws IBSException {
		logger.info("entered into viewAllCreditCards method of CreditCardDaoImpl class");
		boolean result = false;

		CreditCardTransaction d = entityManager.find(CreditCardTransaction.class, transactionId);

		if (d != null) {
			result = true;
		}

		return result;

	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into getCreditCards method of CreditCardDaoImpl class");
		  LocalDateTime fromDate1 = LocalDateTime.now().minusDays(days); 
		  LocalDateTime currentDate1 = LocalDateTime.now();
	
		TypedQuery<CreditCardTransaction> query = entityManager.createQuery(
				"Select d from CreditCardTransaction d JOIN d.creditBeanObject c WHERE d.dateOfTran BETWEEN :start and :end AND c.cardNumber=:cardNum " , CreditCardTransaction.class);
		query.setParameter("start", fromDate1);
		query.setParameter("end", currentDate1);
		query.setParameter("cardNum", creditCardNumber);
		return query.getResultList();
	}

	@Override
	public BigInteger getCreditCardNumber(BigInteger transactionID) throws IBSException {
		logger.info("entered into getCreditCardNumber method of CreditCardDaoImpl class");
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"Select c.cardNumber from CreditCardTransaction d join d.creditBeanObject c where d.transactionId=:transactionId", BigInteger.class);
		query.setParameter("transactionId", transactionID);

		return query.getSingleResult();
	

	}

	@Override
	public BigInteger getCMUci(BigInteger transactionID) throws IBSException {
		logger.info("entered into getCMUci method of CreditCardDaoImpl class");
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"Select d.UCI from CreditCardTransaction d where d.transactionId=:transactionId", BigInteger.class);
		query.setParameter("transactionId", transactionID);

		return query.getSingleResult();
	}

}
