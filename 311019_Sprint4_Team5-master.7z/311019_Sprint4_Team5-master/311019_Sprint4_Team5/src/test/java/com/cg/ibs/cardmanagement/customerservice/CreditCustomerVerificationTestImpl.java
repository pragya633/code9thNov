package com.cg.ibs.cardmanagement.customerservice;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigInteger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.CreditCustomer;
import com.cg.ibs.cardmanagement.service.CreditCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerification;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerificationImpl;

class CreditCustomerVerificationTestImpl {

	
	   
	    CreditCustomerVerification creditVerify = new CreditCustomerVerificationImpl();
	    CreditCustomer creditCustomer = new CreditCustomerClassImpl();

	 

	    
	    @Test
	    void verifyNonExistingCreditCardNumber() {
	        BigInteger creditCardNumber = new BigInteger("523456789101287");
	        Assertions.assertThrows(IBSException.class, () -> {
	            creditVerify.verifyCreditCardNumber(creditCardNumber);
	        });
	    }

	 

	    @Test
	    void verifyExistngCreditCardNumber() {
	        BigInteger creditCardNumber = new BigInteger("5189101213259898");
	        try {
	            assertEquals(true, creditVerify.verifyCreditCardNumber(creditCardNumber));
	        } catch (IBSException e) {
	            fail("Test failed : " + e.getMessage());
	        }

	 

	    }
	    
	    @Test
	    void verifyExistingCreditPin() {
	        BigInteger creditCardNumber = new BigInteger("5189101213259898");
	        String pin="9898";
	        try {
	        assertEquals(true, creditVerify.verifyCreditPin(pin, creditCardNumber));
	        }
	        catch(IBSException e){
	            fail(e.getMessage());
	        }
	    }
	    @Test
	    void verifyCreditCardTransactionId() {
	        BigInteger transactionId = new BigInteger("1236547899");
	        try {
	            assertEquals(true, creditVerify.verifyCreditCardTransactionId(transactionId));    
	        }
	        catch(IBSException e){
	            fail(e.getMessage());
	        }
	        
	    }
	    @Test
	    void verifyCreditCardNonExistingTransactionId() {
	        BigInteger transactionId = new BigInteger("1234567892");
	        Assertions.assertThrows(IBSException.class, () -> {
	            creditVerify.verifyCreditCardTransactionId(transactionId);
	        });        
	        
	    }
	    
	    @Test
	    void verifyCreditCardTypeForValidCard() {
	        BigInteger creditCardNumber = new BigInteger("5189101213259898");
	        try {
	            assertNotNull(creditVerify.verifyCreditcardType(creditCardNumber));    
	        }
	        catch(IBSException e){
	            fail(e.getMessage());
	        }
	        
	    }
	    @Test
	    void verifyCreditCardTypeForInvalidCard() {
	        BigInteger creditCardNumber = new BigInteger("5189101213259895");
	        Assertions.assertThrows(IBSException.class, () -> {
	            creditVerify.verifyCreditcardType(creditCardNumber);
	        });        
	    }
	        
	        @Test
	        void verifyNonExistingCreditPin() {
	            BigInteger creditCardNumber = new BigInteger("5189101213259895");
	            String pin="9895";
	            Assertions.assertThrows(IBSException.class, () -> {
	                creditVerify.verifyCreditPin(pin, creditCardNumber);
	            });        
	    
	        }
	        @Test
	        void verifyCreditCardStatus() {
	            BigInteger creditCardNumber = new BigInteger("5189101213259898");
	            try {
	                assertNotNull(creditVerify.getCreditCardStatus(creditCardNumber));    
	            }
	            catch(IBSException e){
	                fail(e.getMessage());
	            }
	            
	        }
	        @Test
	        void verifyNonExistingCreditCardStatus() {
	            BigInteger creditCardNumber = new BigInteger("5189101213259891");
	            Assertions.assertThrows(IBSException.class, () -> {
	                creditVerify.getCreditCardStatus(creditCardNumber);
	            });        
	            
	        }

}
